import { Pool } from 'pg';

// Local dev: uses DATABASE_URL (set in .dev.vars) for a direct Neon connection.
// Production: uses the Hyperdrive binding, which proxies/pools the same Postgres DB.
let pool: Pool | null = null;

export function getDb(env: Env): Pool {
  if (!pool) {
    const connectionString = env.DATABASE_URL || env.HYPERDRIVE?.connectionString;
    if (!connectionString) {
      throw new Error('No database connection string found. Set DATABASE_URL in .dev.vars or configure Hyperdrive.');
    }
    pool = new Pool({ connectionString });
  }
  return pool;
}
